import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'

// Load environment variables from .env file
dotenv.config();

const app = express();
const PORT = 4000;

// Middleware
app.use(cors()); // Allow all origins
app.use(express.json()); // Parse JSON bodies

// Example route
app.post('/login-sivi', (req, res) => {
    const validUserId = '';
    const loginInput = {
        abstractUId: validUserId
    }

    fetch(`${process.env.SIVI_AUTH_URL}/enterprise-auth/login`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'sivi-api-key': process.env.SIVI_API_KEY
        },
        body: JSON.stringify(loginInput),
    })
        .then(response => {
            return response.json()
        }
        )
        .then(data => res.json(data))
        .catch(error => {
            res.status(500).json({ error: 'Internal Server Error' });
        })
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
